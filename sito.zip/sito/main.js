function buttonClicked(){
	window.alert("Benvenuto su questo sito, lettore. In questo momento il sito è in fase di sviluppo e non presenta nulla d'interessante. Grazie per questa visita!")
}
